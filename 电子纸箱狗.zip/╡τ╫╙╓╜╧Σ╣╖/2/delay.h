#ifndef __Delay_h__
#define __Delay_h__

void Delay(unsigned int xms);

#endif